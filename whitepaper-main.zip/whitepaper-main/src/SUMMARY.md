# Nois Network

[Nois Network](title.md)

- [Abstract](./abstract.md)
- [The Strawman Approach](./the_strawman_approach.md)
- [Our Approach](./our_approach.md)
  - [Security](./security.md)
  - [Performance](./performance.md)
  - [Cost Efficiency](./cost_efficiency.md)
  - [Developer Friendly](./developer_friendly.md)
- [Further Work](./further_work.md)
